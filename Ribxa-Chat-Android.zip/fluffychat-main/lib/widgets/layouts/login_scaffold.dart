// SPDX-FileCopyrightText: 2019-Present Christian Kußowski
// SPDX-FileCopyrightText: 2019-Present Contributors to FluffyChat
//
// SPDX-License-Identifier: AGPL-3.0-or-later

import 'package:fluffychat/config/app_config.dart';
import 'package:fluffychat/config/setting_keys.dart';
import 'package:fluffychat/config/themes.dart';
import 'package:fluffychat/l10n/l10n.dart';
import 'package:fluffychat/utils/platform_infos.dart';
import 'package:material_ui/material_ui.dart';
import 'package:particles_network/particles_network.dart';
import 'package:url_launcher/url_launcher_string.dart';

class LoginScaffold extends StatelessWidget {
  final Widget body;
  final AppBar? appBar;
  final Widget? bottomNavigationBar;

  const LoginScaffold({
    super.key,
    required this.body,
    this.appBar,
    this.bottomNavigationBar,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return LayoutBuilder(
      builder: (context, constraints) {
        final isMobileMode = !FluffyThemes.isColumnModeByWidth(
          constraints.maxWidth,
        );
        if (isMobileMode) {
          return Scaffold(
            key: const Key('LoginScaffold'),
            appBar: appBar,
            body: SafeArea(child: body),
            bottomNavigationBar: bottomNavigationBar,
          );
        }
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                theme.colorScheme.surfaceContainerLow,
                theme.colorScheme.surfaceContainer,
                theme.colorScheme.surfaceContainerHighest,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Stack(
            children: [
              if (!MediaQuery.disableAnimationsOf(context))
                ParticleNetwork(
                  maxSpeed: 0.25,
                  particleColor: theme.colorScheme.primary,
                  lineColor: theme.colorScheme.secondary,
                ),
              Column(
                children: [
                  const SizedBox(height: 16),
                  Expanded(
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Material(
                          borderRadius: BorderRadius.circular(
                            AppConfig.borderRadius,
                          ),
                          clipBehavior: Clip.hardEdge,
                          elevation:
                              theme.appBarTheme.scrolledUnderElevation ?? 4,
                          shadowColor: theme.appBarTheme.shadowColor,
                          child: ConstrainedBox(
                            constraints: isMobileMode
                                ? const BoxConstraints()
                                : const BoxConstraints(
                                    maxWidth: 480,
                                    maxHeight: 640,
                                  ),
                            child: Scaffold(
                              key: const Key('LoginScaffold'),
                              appBar: appBar,
                              body: SafeArea(child: body),
                              bottomNavigationBar: bottomNavigationBar,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const _PrivacyButtons(mainAxisAlignment: .center),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _PrivacyButtons extends StatelessWidget {
  final MainAxisAlignment mainAxisAlignment;
  const _PrivacyButtons({required this.mainAxisAlignment});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final shadowTextStyle = TextStyle(color: theme.colorScheme.secondary);
    return SizedBox(
      height: 64,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: mainAxisAlignment,
          children: [
            TextButton(
              onPressed: () => launchUrlString(AppSettings.website.value),
              child: Text(L10n.of(context).website, style: shadowTextStyle),
            ),
            TextButton(
              onPressed: () => launchUrlString(AppConfig.supportUrl),
              child: Text(L10n.of(context).help, style: shadowTextStyle),
            ),
            TextButton(
              onPressed: () => launchUrlString(AppSettings.privacyPolicy.value),
              child: Text(L10n.of(context).privacy, style: shadowTextStyle),
            ),
            TextButton(
              onPressed: () => PlatformInfos.showDialog(context),
              child: Text(L10n.of(context).about, style: shadowTextStyle),
            ),
          ],
        ),
      ),
    );
  }
}
