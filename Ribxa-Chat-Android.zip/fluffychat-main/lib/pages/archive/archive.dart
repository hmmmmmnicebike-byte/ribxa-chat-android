// SPDX-FileCopyrightText: 2019-Present Christian Kußowski
// SPDX-FileCopyrightText: 2019-Present Contributors to FluffyChat
//
// SPDX-License-Identifier: AGPL-3.0-or-later

import 'package:fluffychat/l10n/l10n.dart';
import 'package:fluffychat/pages/archive/archive_view.dart';
import 'package:fluffychat/widgets/adaptive_dialogs/show_ok_cancel_alert_dialog.dart';
import 'package:fluffychat/widgets/future_loading_dialog.dart';
import 'package:fluffychat/widgets/matrix.dart';
import 'package:material_ui/material_ui.dart';
import 'package:matrix/matrix.dart';

class Archive extends StatefulWidget {
  const Archive({super.key});

  @override
  ArchiveController createState() => ArchiveController();
}

class ArchiveController extends State<Archive> {
  List<ArchivedRoom> archive = [];

  Future<List<ArchivedRoom>> getArchive(BuildContext context) async {
    if (archive.isNotEmpty) return archive;
    return archive = await Matrix.of(context).client.loadArchiveWithTimeline();
  }

  Future<void> forgetRoomAction(int i) async {
    await showFutureLoadingDialog(
      context: context,
      future: () async {
        Logs().v('Forget room ${archive.last.room.getLocalizedDisplayname()}');
        await archive[i].room.forget();
        archive.removeAt(i);
      },
    );
    setState(() {});
  }

  Future<void> forgetAllAction() async {
    final archive = this.archive;
    if (archive.isEmpty) return;
    if (await showOkCancelAlertDialog(
          useRootNavigator: false,
          context: context,
          title: L10n.of(context).areYouSure,
          okLabel: L10n.of(context).yes,
          cancelLabel: L10n.of(context).cancel,
          message: L10n.of(context).clearArchive,
        ) !=
        OkCancelResult.ok) {
      return;
    }
    if (!mounted) return;
    await showFutureLoadingDialog(
      context: context,
      futureWithProgress: (onProgress) async {
        final count = archive.length;
        while (archive.isNotEmpty) {
          onProgress(1 - (archive.length / count));
          Logs().v(
            'Forget room ${archive.last.room.getLocalizedDisplayname()}',
          );
          await archive.last.room.forget();
          archive.removeLast();
        }
      },
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => ArchiveView(this);
}
