// SPDX-FileCopyrightText: 2019-Present Christian Kußowski
// SPDX-FileCopyrightText: 2019-Present Contributors to FluffyChat
//
// SPDX-License-Identifier: AGPL-3.0-or-later

import 'package:file_picker/file_picker.dart';
import 'package:file_selector/file_selector.dart';
import 'package:fluffychat/widgets/app_lock.dart';
import 'package:fluffychat/widgets/future_loading_dialog.dart';
import 'package:flutter/widgets.dart';

Future<List<XFile>> selectFiles(
  BuildContext context, {
  String? title,
  FileType type = FileType.any,
  bool allowMultiple = false,
}) async {
  final result = await AppLock.of(context).pauseWhile(
    showFutureLoadingDialog(
      context: context,
      future: () async {
        if (allowMultiple) {
          final result = await FilePicker.pickFiles(
            type: type,
            dialogTitle: title,
          );
          return result.map((file) => file.xFile).toList();
        }
        final result = await FilePicker.pickFile(
          type: type,
          dialogTitle: title,
        );
        return [?result?.xFile];
      },
    ),
  );
  return result.result ?? [];
}
